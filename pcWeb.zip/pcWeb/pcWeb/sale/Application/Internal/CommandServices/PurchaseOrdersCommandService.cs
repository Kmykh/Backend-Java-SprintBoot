using pcWeb.sale.Domain.Model.Aggregates;
using pcWeb.sale.Domain.Model.Commands;
using pcWeb.sale.Domain.Repositories;
using pcWeb.sale.Domain.Services;
using pcWeb.Shared.Domain.Repositories;

namespace pcWeb.sale.Application.Internal.CommandServices;

public class PurchaseOrdersCommandService(IPurchaseOrdersRepository purchaseOrdersRepository,
    IUnitOfWork unitOfWork) : IPurchaseOrdersCommandService
{
    public async Task<PurchaseOrders> Handle(CreatePurchaseOrdersCommand command)
    {
        // Verifica si ya existe una orden de compra con el mismo Cliente y FabricId
        var existingPurchaseOrder = await purchaseOrdersRepository
            .FindByCustomerAndFrabricIdAsync(command.Customer, command.FabricId);

        //Si ya existe una orden de compra con el mismo Cliente y FabricId, lanza una excepción
        if (existingPurchaseOrder != null)
        {
            throw new InvalidOperationException("No se puede crear dos órdenes de compra con el mismo cliente y FabricId.");
        }

        // Crea una nueva orden de compra
        var purchaseOrders = new PurchaseOrders(command);
        await purchaseOrdersRepository.AddAsync(purchaseOrders);
        await unitOfWork.CompleteAsync();
        return purchaseOrders;
    }
}
