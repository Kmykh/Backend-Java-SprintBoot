using pcWeb.sale.Domain.Model.Aggregates;
using pcWeb.sale.Domain.Model.Queries;
using pcWeb.sale.Domain.Repositories;
using pcWeb.sale.Domain.Services;

namespace pcWeb.sale.Application.Internal.QueryServices;
/**
 * Clase que implementa la interfaz IPurchaseOrdersQueryService
 */

public class PurchaseOrdersQueryService(IPurchaseOrdersRepository purchaseOrdersRepository) : IPurchaseOrdersQueryService
{
    //esta parte es la que se encarga de hacer la consulta a la base de datos con el customer y el fabricId
    public async Task<PurchaseOrders?> Handle(GetCustomerAndFrabricIdQuery query)
    {
        return await purchaseOrdersRepository.FindByCustomerAndFrabricIdAsync(query.Customer, query.FabricId);
    }
}