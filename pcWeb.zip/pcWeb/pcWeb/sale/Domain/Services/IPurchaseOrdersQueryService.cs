using pcWeb.sale.Domain.Model.Aggregates;
using pcWeb.sale.Domain.Model.Commands;
using pcWeb.sale.Domain.Model.Queries;

namespace pcWeb.sale.Domain.Services;

/**
 * interface IPurchaseOrdersQueryService
 * sirve para definir los metodos que se van a implementar en la clase PurchaseOrdersQueryService
 * para conseguir el customer y el fabricId
 */
public interface IPurchaseOrdersQueryService
{
    Task<PurchaseOrders?>Handle(GetCustomerAndFrabricIdQuery query);
}