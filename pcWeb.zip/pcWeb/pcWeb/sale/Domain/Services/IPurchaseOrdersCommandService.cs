using pcWeb.sale.Domain.Model.Aggregates;
using pcWeb.sale.Domain.Model.Commands;

namespace pcWeb.sale.Domain.Services;

/*
 * implementacion de la interfaz de servicio de comandos de ordenes de compra
 * que sirve para crear una orden de compra
 */

public interface IPurchaseOrdersCommandService
{
    public Task<PurchaseOrders>Handle(CreatePurchaseOrdersCommand command);
}