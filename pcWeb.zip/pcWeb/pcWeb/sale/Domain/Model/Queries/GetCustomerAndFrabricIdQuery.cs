namespace pcWeb.sale.Domain.Model.Queries;


/*
 * para hacer el No permite que se registre dos purchase orders con el mismo customer y fabricId 
 */
public record GetCustomerAndFrabricIdQuery(string Customer, int FabricId);