namespace pcWeb.sale.Domain.Model.Commands;
/**
 * se crea la clase CreatePurchaseOrdersCommand
 * se crea el constructor de la clase CreatePurchaseOrdersCommand
 * se ponen los atributos de la clase CreatePurchaseOrdersCommand sin el id
 */
public record CreatePurchaseOrdersCommand(string Customer, int FabricId, string City, string ResumeUrl, int Quantity);