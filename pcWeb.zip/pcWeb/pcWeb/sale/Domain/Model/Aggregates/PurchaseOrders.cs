using System;
using System.ComponentModel.DataAnnotations.Schema;
using pcWeb.sale.Domain.Model.Commands;

namespace pcWeb.sale.Domain.Model.Aggregates
{
    /**
     * PurchaseOrders Aggregate
     * EFabric Enum
        * Id Name 
        *1 Algodon 
        *2 Modal 
        *3 Elastano 
        *4 Poliester 
        *5 Nailon 
        *6 Acrilico 
        *7 Rayon 
        *8 Lyocell 
     */
    public enum EFabric
    {
        Algodon = 1,
        Modal = 2,
        Elastano = 3,
        Poliester = 4,
        Nailon = 5,
        Acrilico = 6,
        Rayon = 7,
        Lyocell = 8
    }

    /**
     * PurchaseOrders Aggregate
     * PurchaseOrders Class
     */
    
    public partial class PurchaseOrders
    {
        public int Id { get; private set; }
        public string Customer { get; private set; }
        /**
         * EFabric Enum
         * EFabric es un Enum que contiene los tipos de telas que se pueden comprar por eso se declara como EFabric
         * porque es un Enum que se puede usar en la entidad PurchaseOrders jala los valores de EFabric
         */
        public EFabric FabricId { get; private set; } 
        public string City { get; private set; }
        public string ResumeUrl { get; private set; }
        public int Quantity { get; private set; }
        
        /**
         * Audit Fields
         * son para el seguimiento de los cambios en la entidad
         */
        [Column("CreatedAt")] public DateTimeOffset? CreatedDate { get; set; }
        [Column("UpdatedAt")] public DateTimeOffset? UpdatedDate { get; set; }
        
        
        /**
         * Constructor
         */
        
        protected PurchaseOrders()
        {
            this.Customer = string.Empty;
            this.City = string.Empty;
            this.ResumeUrl = string.Empty;
        }

        public PurchaseOrders(CreatePurchaseOrdersCommand command)
        {
            this.Customer = command.Customer;
            this.FabricId = (EFabric)command.FabricId; 
            this.City = command.City;
            this.ResumeUrl = command.ResumeUrl;
            this.Quantity = command.Quantity;
            this.CreatedDate = DateTimeOffset.UtcNow;
            this.UpdatedDate = DateTimeOffset.UtcNow;
        }
    }
}