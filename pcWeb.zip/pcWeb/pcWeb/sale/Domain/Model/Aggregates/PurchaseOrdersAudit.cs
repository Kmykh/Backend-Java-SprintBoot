using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using EntityFrameworkCore.CreatedUpdatedDate.Contracts;

namespace pcWeb.sale.Domain.Model.Aggregates;

/**
 * PurchaseOrders Aggregate
 * este es el modelo de PurchaseOrdersAudit
 * que se encarga de llevar el registro de los cambios
 */
public partial class PurchaseOrdersAudit: IEntityWithCreatedUpdatedDate
{
    [Key]
    public int Id { get; set; }
    [Column("CreatedAt")] public DateTimeOffset? CreatedDate { get; set; }
    [Column("UpdatedAt")] public DateTimeOffset? UpdatedDate { get; set; }
}