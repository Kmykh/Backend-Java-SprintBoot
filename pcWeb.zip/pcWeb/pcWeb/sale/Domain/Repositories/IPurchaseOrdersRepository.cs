using pcWeb.sale.Domain.Model.Aggregates;
using pcWeb.Shared.Domain.Repositories;

namespace pcWeb.sale.Domain.Repositories;
/*
 * IPurchaseOrdersRepository
 * es una interfaz que hereda de IBaseRepository<PurchaseOrders>
 * para poder implementar los métodos de la interfaz base
 * y además se agrega un método adicional para buscar una orden de compra por cliente y id de tela
 */
public interface IPurchaseOrdersRepository: IBaseRepository<PurchaseOrders>
{
    Task<PurchaseOrders?> FindByCustomerAndFrabricIdAsync(string customer, int fabricId);
    
}