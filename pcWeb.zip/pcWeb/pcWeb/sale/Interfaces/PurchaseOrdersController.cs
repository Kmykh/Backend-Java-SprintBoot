using System.Net.Mime;
using Microsoft.AspNetCore.Mvc;
using pcWeb.sale.Domain.Model.Queries;
using pcWeb.sale.Domain.Services;
using pcWeb.sale.Interfaces.REST.Resources;
using pcWeb.sale.Interfaces.REST.Transform;
using Swashbuckle.AspNetCore.Annotations;
namespace pcWeb.sale.Interfaces;
/**
 * PurchaseOrdersController
 * es el controlador de la entidad PurchaseOrders
 */
[ApiController]
[Route("api/v1/purchase-orders")]
[Produces(MediaTypeNames.Application.Json)]
public class PurchaseOrdersController( IPurchaseOrdersCommandService purchaseOrdersCommandService,
    IPurchaseOrdersQueryService purchaseOrdersQueryService) : ControllerBase
{

    [HttpPost]
    [SwaggerOperation(
        Summary = "Create a Purchase Order",
        Description = "Create a Purchase Order with a given customer and fabric id",
        OperationId = "CreatePurchaseOrders")]
    // aqui se pone el swagger response para que se documente en el swagger status code 201 es para cuando se crea un recurso
    [SwaggerResponse(201, "The PurchaseOrders was created", typeof(PurchaseOrdersResource))]
    [HttpPost]
    
    /*
     * CreatePurchaseOrders
     * es el metodo que se encarga de crear una orden de compra
     * @param createPurchaseOrdersResource es el recurso que se recibe para crear la orden de compra
     * @return IActionResult
     */
    
    public async Task<IActionResult> CreatePurchaseOrders([FromBody] CreatePurchaseOrdersResource createPurchaseOrdersResource)
    {
        var createPurchaseOrdersCommand =
            CreatePurchaseOrdersCommandFromResourceAssembler.toCommandFromResource(createPurchaseOrdersResource);
        var purchaseOrders = await purchaseOrdersCommandService.Handle(createPurchaseOrdersCommand);
        if (purchaseOrders is null) return BadRequest();
        var resource = PurchaseOrdersResourceFromEntityAssembler.toResourceFromEntity(purchaseOrders);
        return Ok(resource);
    }
    
}