namespace pcWeb.sale.Interfaces.REST.Resources;

/**
 * Representa los datos necesarios para crear una orden de compra.
 * @param Customer El nombre del cliente.
 * @param FabricId El identificador del tejido.
 * @param City La ciudad de destino.
 * @param ResumeUrl La URL del resumen de la orden.
 * @param Quantity La cantidad de tejido.
 */
public record CreatePurchaseOrdersResource(string Customer, int FabricId, string City, string ResumeUrl, int Quantity);