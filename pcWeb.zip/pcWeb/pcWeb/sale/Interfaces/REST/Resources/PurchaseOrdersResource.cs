namespace pcWeb.sale.Interfaces.REST.Resources;
/**
 * PurchaseOrdersResource
 * @param Id
 * @param Customer
 * @param FabricId
 * @param City
 * @param ResumeUrl
 * @param Quantity
 */
public record PurchaseOrdersResource(int Id,string Customer, int FabricId, string City, string ResumeUrl, int Quantity);
