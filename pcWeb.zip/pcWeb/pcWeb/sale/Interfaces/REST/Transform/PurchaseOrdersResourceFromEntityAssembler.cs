using pcWeb.sale.Domain.Model.Aggregates;
using pcWeb.sale.Interfaces.REST.Resources;

/**
 * PurchaseOrdersResourceFromEntityAssembler
 * se encarga de transformar un objeto de tipo PurchaseOrders a un objeto de tipo PurchaseOrdersResource
 */
public class PurchaseOrdersResourceFromEntityAssembler
{
    public static PurchaseOrdersResource toResourceFromEntity(PurchaseOrders entity)
    {
        return new PurchaseOrdersResource(entity.Id, entity.Customer, (int)entity.FabricId, entity.City, entity.ResumeUrl,
            entity.Quantity);
    }
}