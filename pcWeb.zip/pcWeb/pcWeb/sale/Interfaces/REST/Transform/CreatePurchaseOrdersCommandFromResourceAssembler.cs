using pcWeb.sale.Domain.Model.Commands;
using pcWeb.sale.Interfaces.REST.Resources;

namespace pcWeb.sale.Interfaces.REST.Transform;
/**
 * la clase es responsable de transformar un recurso en un comando
 * para crear una orden de compra
 */
public class CreatePurchaseOrdersCommandFromResourceAssembler
{
    public static CreatePurchaseOrdersCommand toCommandFromResource(CreatePurchaseOrdersResource resource)
    {
        return new CreatePurchaseOrdersCommand(resource.Customer, resource.FabricId, resource.City, 
            resource.ResumeUrl, resource.Quantity);
    }
    
}