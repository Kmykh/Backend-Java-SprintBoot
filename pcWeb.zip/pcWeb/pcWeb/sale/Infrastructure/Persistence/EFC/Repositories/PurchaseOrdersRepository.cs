using ACME.LearningCenterPlatform.API.Shared.Infrastructure.Persistence.EFC.Repositories;
using Microsoft.EntityFrameworkCore;
using pcWeb.sale.Domain.Model.Aggregates;
using pcWeb.sale.Domain.Repositories;
using pcWeb.Shared.Infrastructure.Persistence.EFC.Configuration;

namespace pcWeb.sale.Infrastructure.Persistence.EFC.Repositories
{
    /**
     * <summary>
     *  PurchaseOrdersRepository
     * </summary>
     * <remarks>
     *  This class is used to implement the PurchaseOrdersRepository interface 
     * </remarks>
     */
    public class PurchaseOrdersRepository: BaseRepository<PurchaseOrders>,IPurchaseOrdersRepository
    {
        // Constructor
        public PurchaseOrdersRepository(AppDbContext context) : base(context)
        {
        }
        // FindByCustomerAndFrabricIdAsync hace que se busque un pedido por cliente y id de tela
        public async Task<PurchaseOrders?> FindByCustomerAndFrabricIdAsync(string customer, int fabricId)
        {
            EFabric fabricEnum = (EFabric)fabricId;
            return await Context.Set<PurchaseOrders>().FirstOrDefaultAsync(p => p.Customer == customer  && p.FabricId == fabricEnum);
        }
    }
}