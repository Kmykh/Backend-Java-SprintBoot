using ACME.LearningCenterPlatform.API.Shared.Infrastructure.Persistence.EFC.Configuration.Extensions;
using EntityFrameworkCore.CreatedUpdatedDate.Extensions;
using Microsoft.EntityFrameworkCore;
using pcWeb.sale.Domain.Model.Aggregates;

namespace pcWeb.Shared.Infrastructure.Persistence.EFC.Configuration;

public class AppDbContext(DbContextOptions options) : DbContext(options)
{
    protected override void OnConfiguring(DbContextOptionsBuilder builder)
    {
        base.OnConfiguring(builder);
        // Enable Audit Fields Interceptors
        builder.AddCreatedUpdatedInterceptor();
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        
        // Begin BoundedContext Model
        
        
        // PurchaseOrders Context
        //aqui se configura el modelo de datos de la tabla de ventas
        builder.Entity<PurchaseOrders>().HasKey(p => p.Id);
        builder.Entity<PurchaseOrders>().Property(p => p.Id).IsRequired().ValueGeneratedOnAdd();
        builder.Entity<PurchaseOrders>().Property(p => p.Customer).IsRequired();
        builder.Entity<PurchaseOrders>().Property(p => p.FabricId).IsRequired();
        builder.Entity<PurchaseOrders>().Property(p => p.City).IsRequired();
        builder.Entity<PurchaseOrders>().Property(p => p.ResumeUrl).IsRequired();
        builder.Entity<PurchaseOrders>().Property(p => p.Quantity).IsRequired();
        
        // PurchaseOrdersAudit Context
        //aqui se configura el modelo de datos de la tabla de auditoria de ventas
        //que es la que se va a usar para guardar los cambios en la tabla de ventas
        builder.Entity<PurchaseOrdersAudit>().Property(p => p.CreatedDate).HasDefaultValueSql("CURRENT_TIMESTAMP").ValueGeneratedOnAdd();
        builder.Entity<PurchaseOrdersAudit>()
            .Property(p => p.UpdatedDate)
            .HasDefaultValueSql("CURRENT_TIMESTAMP")
            .ValueGeneratedOnAddOrUpdate();
        
        
        
        // Agregando una restricción única para Cliente y FabricId
        builder.Entity<PurchaseOrders>().HasIndex(p => new { p.Customer, p.FabricId }).IsUnique();
        
        
        // End BoundedContext Model
        
        builder.UseSnakeCaseWithPluralizedTableNamingConvention();
    }
}