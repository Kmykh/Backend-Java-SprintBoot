using ACME.LearningCenterPlatform.API.Shared.Infrastructure.Persistence.EFC.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using pcWeb.sale.Application.Internal.CommandServices;
using pcWeb.sale.Application.Internal.QueryServices;
using pcWeb.sale.Domain.Repositories;
using pcWeb.sale.Domain.Services;
using pcWeb.sale.Infrastructure.Persistence.EFC.Repositories;
using pcWeb.Shared.Domain.Repositories;
using pcWeb.Shared.Infrastructure.Persistence.EFC.Configuration;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

// Add Database Connection
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

// Configure Database Context and Logging Levels
builder.Services.AddDbContext<AppDbContext>(options =>
{
    if (connectionString == null) return;
    if (builder.Environment.IsDevelopment())
        options.UseMySQL(connectionString)
            .LogTo(Console.WriteLine, LogLevel.Information)
            .EnableSensitiveDataLogging()
            .EnableDetailedErrors();
    else if (builder.Environment.IsProduction())
        options.UseMySQL(connectionString)
            .LogTo(Console.WriteLine, LogLevel.Error)
            .EnableDetailedErrors();
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(
    c =>
    {
        c.SwaggerDoc("v1",
            new OpenApiInfo()
            {
                //aqui se cambia el nombre de acuerdo al proyecto
                Title = "Cotton Knit SAC.",
                Version = "v1",
                Description = "Cotton Knit",
                TermsOfService = new Uri("https://cottonknit.com/tos"),
                Contact = new OpenApiContact
                {
                    Name = " Cotton Knit SAC.",
                    Email = "contact@cottonknit.com"
                },
                License = new OpenApiLicense
                {
                    Name = "Apache 2.0",
                    Url = new Uri("https://www.apache.org/licenses/LICENSE-2.0.html")
                }
            });
        c.EnableAnnotations();
    });

// Configure Lowercase Urls
builder.Services.AddRouting(options => options.LowercaseUrls = true);
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Configure Dependency Injection
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>(); // Add this line

//
//
//

// Configuración de inyección de contexto delimitado de PurchaseOrders 

// primero va el de domain.repositories   y luego  el de infraestructure.persistence.efc.repositories
builder.Services.AddScoped<IPurchaseOrdersRepository, PurchaseOrdersRepository>();

// primero va el de domain.services   y luego  el de application.internal.commandservices
builder.Services.AddScoped<IPurchaseOrdersCommandService, PurchaseOrdersCommandService>();

//primer va el de domain.services y luego el de application.internal.queryservices
builder.Services.AddScoped<IPurchaseOrdersQueryService, PurchaseOrdersQueryService>();

//termina la configuración de inyección de contexto delimitado de PurchaseOrders
//
//


var app = builder.Build();

// Verify Database Objects are Created
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var context = services.GetRequiredService<AppDbContext>();
    context.Database.EnsureCreated();
}

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();